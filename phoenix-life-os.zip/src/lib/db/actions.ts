"use server";

import { revalidatePath } from "next/cache";
import { z } from "zod";

import {
  createHealthMetric,
  createIncome,
  createNote,
  deleteNote,
  toggleHabit,
  updateJobStage,
  updateNote,
  updateProjectProgress,
} from "@/lib/db";

const noteSchema = z.object({
  id: z.string().optional(),
  title: z.string().trim().min(1, "Title is required").max(120),
  content: z.string().max(20_000),
  tag: z.string().trim().min(1, "Tag is required").max(40),
  pinned: z.boolean(),
});

const habitSchema = z.object({
  habitId: z.string(),
  date: z.string(),
  completed: z.boolean(),
});

const jobSchema = z.object({
  id: z.string(),
  stage: z.enum(["APPLIED", "INTERVIEW", "OFFER", "REJECTED"]),
});

const projectSchema = z.object({
  id: z.string(),
  progress: z.number().int().min(0).max(100),
});

const incomeSchema = z.object({
  source: z.string().min(1),
  amount: z.number().nonnegative(),
  goal: z.number().nonnegative().optional(),
  type: z.enum(["FREELANCE", "REMOTE_JOB", "SAVINGS", "OTHER"]),
  month: z.coerce.date(),
});

const healthSchema = z.object({
  date: z.coerce.date(),
  weight: z.number().positive().optional(),
  sleep: z.number().nonnegative().optional(),
  water: z.number().nonnegative().optional(),
  steps: z.number().int().nonnegative().optional(),
  workouts: z.number().int().nonnegative().optional(),
  heartRate: z.number().int().positive().optional(),
});

/* -------------------------------------------------------------------------- */
/* Notes                                                                      */
/* -------------------------------------------------------------------------- */

export async function saveNote(input: z.input<typeof noteSchema>) {
  const data = noteSchema.parse(input);

  const { id, ...noteData } = data;

  const note = id ? await updateNote(id, noteData) : await createNote(noteData);

  revalidatePath("/notes");
  revalidatePath("/");

  return note;
}

export async function removeNote(id: string) {
  await deleteNote(z.string().parse(id));

  revalidatePath("/notes");
  revalidatePath("/");
}

/* -------------------------------------------------------------------------- */
/* Habits                                                                     */
/* -------------------------------------------------------------------------- */

export async function setHabit(input: z.input<typeof habitSchema>) {
  const data = habitSchema.parse(input);

  await toggleHabit(data.habitId, data.date, data.completed);

  revalidatePath("/habits");
  revalidatePath("/");
}

/* -------------------------------------------------------------------------- */
/* Career                                                                     */
/* -------------------------------------------------------------------------- */

export async function setJobStage(input: z.input<typeof jobSchema>) {
  const data = jobSchema.parse(input);

  await updateJobStage(data.id, data.stage);

  revalidatePath("/career");
  revalidatePath("/");
}

/* -------------------------------------------------------------------------- */
/* Engineering                                                                */
/* -------------------------------------------------------------------------- */

export async function setProjectProgress(input: z.input<typeof projectSchema>) {
  const data = projectSchema.parse(input);

  await updateProjectProgress(data.id, data.progress);

  revalidatePath("/engineering");
  revalidatePath("/");
}

/* -------------------------------------------------------------------------- */
/* Income                                                                     */
/* -------------------------------------------------------------------------- */

export async function addIncome(input: z.input<typeof incomeSchema>) {
  const data = incomeSchema.parse(input);

  await createIncome(data);

  revalidatePath("/income");
  revalidatePath("/");
}

/* -------------------------------------------------------------------------- */
/* Health                                                                     */
/* -------------------------------------------------------------------------- */

export async function saveHealth(input: z.input<typeof healthSchema>) {
  const data = healthSchema.parse(input);

  await createHealthMetric(data);

  revalidatePath("/health");
  revalidatePath("/");
}
