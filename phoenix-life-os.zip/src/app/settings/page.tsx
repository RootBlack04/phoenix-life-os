import { AppShell } from "@/components/layout/app-shell";
import { SettingsClient } from "@/components/domain/settings-client";
export const dynamic="force-dynamic";
export default async function SettingsPage(){return <AppShell title="Settings"><SettingsClient/></AppShell>}
