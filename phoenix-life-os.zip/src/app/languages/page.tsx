import { AppShell } from "@/components/layout/app-shell";
import { Card, CardHeader } from "@/components/ui/card";
import { ProgressRing } from "@/components/ui/progress-ring";
import { DetailProgress } from "@/components/ui/detail-progress";
import { Badge } from "@/components/ui/badge";
import { LanguageChart } from "@/components/charts/language-chart";
import { getLanguages } from "@/lib/db";

export const dynamic = "force-dynamic";

export default async function LanguagesPage() {
  const languages = await getLanguages();

  return (
    <AppShell title="Languages">
      <div className="grid grid-cols-1 xl:grid-cols-2 gap-6">
        {languages.map((l) => (
          <Card key={l.id}>
            <div className="flex items-start justify-between mb-5">
              <div className="flex items-center gap-3">
                <span className="text-3xl">{l.flag}</span>

                <div>
                  <h3 className="font-display text-lg font-semibold text-text-primary">
                    {l.name}
                  </h3>

                  <div className="flex items-center gap-2 mt-1">
                    <Badge tone="blue">{l.currentLevel}</Badge>

                    <span className="text-text-tertiary text-xs">→</span>

                    <Badge tone="purple">{l.targetLevel} target</Badge>
                  </div>
                </div>
              </div>

              <ProgressRing
                percent={l.percent}
                size={72}
                strokeWidth={6}
                color="var(--accent-blue)"
                colorTo="var(--accent-purple)"
              >
                <span className="font-display text-sm font-bold">
                  {l.percent}%
                </span>
              </ProgressRing>
            </div>

            <div className="grid grid-cols-2 gap-x-6 gap-y-4 mb-5">
              <DetailProgress label="Vocabulary" percent={l.vocabulary} />

              <DetailProgress label="Grammar" percent={l.grammar} />

              <DetailProgress label="Listening" percent={l.listening} />

              <DetailProgress label="Speaking" percent={l.speaking} />

              <DetailProgress label="Writing" percent={l.writing} />

              <DetailProgress label="Reading" percent={l.reading} />
            </div>

            <div className="grid grid-cols-3 gap-3 mb-5">
              <div className="glass rounded-xl p-3 text-center">
                <p className="font-display text-lg font-bold text-text-primary">
                  {l.hoursLogged}h
                </p>

                <p className="text-[10px] text-text-tertiary mt-0.5">
                  Hours logged
                </p>
              </div>

              <div className="glass rounded-xl p-3 text-center">
                <p className="font-display text-lg font-bold text-text-primary">
                  {l.dailyGoalMinutes}m
                </p>

                <p className="text-[10px] text-text-tertiary mt-0.5">
                  Daily goal
                </p>
              </div>

              <div className="glass rounded-xl p-3 text-center">
                <p className="font-display text-lg font-bold text-text-primary">
                  {l.weeklyGoalHours}h
                </p>

                <p className="text-[10px] text-text-tertiary mt-0.5">
                  Weekly goal
                </p>
              </div>
            </div>

            <CardHeader title="CEFR Progress" className="mb-2" />

            <div className="h-[120px] -ml-4">
              <LanguageChart data={l.weeklyTrend} />
            </div>
          </Card>
        ))}
      </div>
    </AppShell>
  );
}
